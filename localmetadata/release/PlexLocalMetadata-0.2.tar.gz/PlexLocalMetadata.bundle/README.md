License
-------

Software contained in this package is licenced with the Apache License, Version 2.0 license that can be found at https://opensource.org/license/apache-2-0/
